"""
Core reconciliation logic, executed entirely on a Databricks SQL
Warehouse via the Statement Execution API - no Spark, no job cluster.
The comparison itself (EXCEPT ALL / anti-join) runs as SQL on the
warehouse; this module is orchestration + polling + safety checks.

Two comparison modes:

- "full_row" (default): every column must match exactly, INCLUDING
  duplicate rows (two identical source rows need two matching target
  rows, not just one). Uses EXCEPT ALL, not plain EXCEPT - plain
  EXCEPT is EXCEPT DISTINCT under the hood and silently drops
  duplicates before comparing, which would report a false PASS if a
  source row is duplicated but the target only has one copy.

- "key": only a business key needs to exist in both tables; other
  column values are not compared. Uses NOT EXISTS keyed on the given
  columns.

Before either comparison runs, schemas are checked: for full_row mode
this also means selecting both sides by an explicit, identically
ordered column list (not SELECT *), because EXCEPT/EXCEPT ALL compare
column-by-position - if the two tables' columns are in a different
physical order, SELECT * would silently compare the wrong values
against each other even though both tables have the same columns.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, asdict

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import StatementState

logger = logging.getLogger("recon_framework")

SAMPLE_LIMIT = 20
POLL_INTERVAL_SECONDS = 2
MAX_WAIT_SECONDS = 300  # give a suspended/auto-starting warehouse time to spin up


@dataclass
class ReconResult:
    source: str
    target: str
    compare_mode: str
    source_row_count: int
    target_row_count: int
    missing_in_target: int
    status: str  # "PASS" or "FAIL"

    def as_dict(self) -> dict:
        return asdict(self)


class SchemaMismatchError(ValueError):
    """Raised when source and target don't have the same set of
    columns (full_row mode) or a key column is missing (key mode)."""


def _execute(w: WorkspaceClient, warehouse_id: str, statement: str):
    """Run one SQL statement on the warehouse and block until it
    finishes, polling if it doesn't complete inside the synchronous
    wait window (e.g. the warehouse was stopped and is auto-starting)."""
    resp = w.statement_execution.execute_statement(
        warehouse_id=warehouse_id,
        statement=statement,
        wait_timeout="30s",
    )
    elapsed = 0
    while resp.status.state in (StatementState.PENDING, StatementState.RUNNING):
        if elapsed >= MAX_WAIT_SECONDS:
            raise TimeoutError(
                f"Statement did not finish within {MAX_WAIT_SECONDS}s: {statement}"
            )
        time.sleep(POLL_INTERVAL_SECONDS)
        elapsed += POLL_INTERVAL_SECONDS
        resp = w.statement_execution.get_statement(resp.statement_id)

    if resp.status.state != StatementState.SUCCEEDED:
        raise RuntimeError(
            f"Statement failed ({resp.status.state}): {resp.status.error}\nSQL: {statement}"
        )
    return resp


def _scalar(w: WorkspaceClient, warehouse_id: str, statement: str) -> int:
    resp = _execute(w, warehouse_id, statement)
    rows = resp.result.data_array or []
    return int(rows[0][0]) if rows else 0


def _sample_rows(w: WorkspaceClient, warehouse_id: str, statement: str) -> list:
    resp = _execute(w, warehouse_id, statement)
    return resp.result.data_array or []


def get_columns(w: WorkspaceClient, warehouse_id: str, catalog: str, schema: str, table: str) -> list[str]:
    """Ordered column names for a table, via Unity Catalog's
    information_schema (works the same way on any UC catalog)."""
    sql = (
        f"SELECT column_name FROM {catalog}.information_schema.columns "
        f"WHERE table_schema = '{schema}' AND table_name = '{table}' "
        f"ORDER BY ordinal_position"
    )
    resp = _execute(w, warehouse_id, sql)
    return [row[0] for row in (resp.result.data_array or [])]


def _check_full_row_schema(
    w: WorkspaceClient, warehouse_id: str,
    source_catalog: str, source_schema: str, source_table: str,
    target_catalog: str, target_schema: str, target_table: str,
) -> list[str]:
    """Verify source and target have the same set of columns, and
    return the column list (source's order) to select explicitly by
    on both sides - so EXCEPT ALL compares matching columns even if
    the two tables store them in a different physical order."""
    source_cols = get_columns(w, warehouse_id, source_catalog, source_schema, source_table)
    target_cols = get_columns(w, warehouse_id, target_catalog, target_schema, target_table)

    source_set, target_set = set(source_cols), set(target_cols)
    if source_set != target_set:
        only_in_source = sorted(source_set - target_set)
        only_in_target = sorted(target_set - source_set)
        raise SchemaMismatchError(
            "Source and target columns don't match - full_row comparison "
            "requires identical column sets.\n"
            f"Only in source: {only_in_source or '(none)'}\n"
            f"Only in target: {only_in_target or '(none)'}\n"
            "Use compare_mode='key' if the tables are expected to differ "
            "in shape, or fix the schema drift first."
        )
    return source_cols


def _check_key_columns_exist(
    w: WorkspaceClient, warehouse_id: str,
    source_catalog: str, source_schema: str, source_table: str,
    target_catalog: str, target_schema: str, target_table: str,
    key_columns: list[str],
) -> None:
    source_cols = set(get_columns(w, warehouse_id, source_catalog, source_schema, source_table))
    target_cols = set(get_columns(w, warehouse_id, target_catalog, target_schema, target_table))
    missing_in_source = [c for c in key_columns if c not in source_cols]
    missing_in_target = [c for c in key_columns if c not in target_cols]
    if missing_in_source or missing_in_target:
        raise SchemaMismatchError(
            "Key column(s) not found.\n"
            f"Missing from source: {missing_in_source or '(none)'}\n"
            f"Missing from target: {missing_in_target or '(none)'}"
        )


def _full_row_missing_sql(source_fqn: str, target_fqn: str, columns: list[str]) -> str:
    col_list = ", ".join(columns)
    return (
        f"SELECT {col_list} FROM {source_fqn} "
        f"EXCEPT ALL "
        f"SELECT {col_list} FROM {target_fqn}"
    )


def _key_missing_sql(source_fqn: str, target_fqn: str, key_columns: list[str]) -> str:
    join_cond = " AND ".join(f"s.{c} = t.{c}" for c in key_columns)
    return (
        f"SELECT s.* FROM {source_fqn} s "
        f"WHERE NOT EXISTS (SELECT 1 FROM {target_fqn} t WHERE {join_cond})"
    )


def reconcile(
    w: WorkspaceClient,
    warehouse_id: str,
    source_fqn: str,
    target_fqn: str,
    compare_mode: str = "full_row",
    key_columns: list[str] | None = None,
    include_row_samples: bool = False,
) -> ReconResult:
    """Run the reconciliation on the given SQL Warehouse and return a
    ReconResult. source_fqn / target_fqn are full three-level names,
    e.g. "prod_catalog.sales.orders".

    include_row_samples controls whether mismatched row *values* get
    logged on failure. Defaults to False: logs only counts, since the
    tables being reconciled may hold sensitive data that shouldn't
    land in job run logs by default. Turn on deliberately for
    non-sensitive/test data if you want to see the actual rows.
    """
    logger.info(
        "Reconciling %s -> %s (mode=%s) on warehouse %s",
        source_fqn, target_fqn, compare_mode, warehouse_id,
    )
    source_catalog, source_schema, source_table = source_fqn.split(".")
    target_catalog, target_schema, target_table = target_fqn.split(".")

    if compare_mode == "full_row":
        columns = _check_full_row_schema(
            w, warehouse_id,
            source_catalog, source_schema, source_table,
            target_catalog, target_schema, target_table,
        )
        missing_sql = _full_row_missing_sql(source_fqn, target_fqn, columns)
    elif compare_mode == "key":
        if not key_columns:
            raise ValueError("compare_mode='key' requires at least one key column")
        _check_key_columns_exist(
            w, warehouse_id,
            source_catalog, source_schema, source_table,
            target_catalog, target_schema, target_table,
            key_columns,
        )
        missing_sql = _key_missing_sql(source_fqn, target_fqn, key_columns)
    else:
        raise ValueError(f"Unknown compare_mode: {compare_mode!r}")

    missing_count = _scalar(w, warehouse_id, f"SELECT COUNT(*) FROM ({missing_sql})")

    if missing_count > 0:
        if include_row_samples:
            sample = _sample_rows(w, warehouse_id, f"{missing_sql} LIMIT {SAMPLE_LIMIT}")
            logger.warning(
                "%d row(s) in %s not found in %s (showing up to %d): %s",
                missing_count, source_fqn, target_fqn, SAMPLE_LIMIT, sample,
            )
        else:
            logger.warning(
                "%d row(s) in %s not found in %s (row samples not logged - "
                "pass include_row_samples=True to see values)",
                missing_count, source_fqn, target_fqn,
            )

    source_row_count = _scalar(w, warehouse_id, f"SELECT COUNT(*) FROM {source_fqn}")
    target_row_count = _scalar(w, warehouse_id, f"SELECT COUNT(*) FROM {target_fqn}")

    result = ReconResult(
        source=source_fqn,
        target=target_fqn,
        compare_mode=compare_mode,
        source_row_count=source_row_count,
        target_row_count=target_row_count,
        missing_in_target=missing_count,
        status="PASS" if missing_count == 0 else "FAIL",
    )
    logger.info("Result: %s", result.as_dict())
    return result

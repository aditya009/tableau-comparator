# data-recon-framework

Compares a source `catalog.schema.table` against a target
`catalog.schema.table` in Databricks Unity Catalog and reports
PASS/FAIL. All comparison work runs as SQL on a **Databricks SQL
Warehouse** - there is no Spark session and no job cluster anywhere
in this framework. Deployable as a Databricks Job via Databricks
Asset Bundles, triggerable from GitLab CI.

## Architecture

- `catalog_utils.py` authenticates to the workspace and lists/validates
  catalogs, schemas, and tables (Unity Catalog metadata calls - no
  compute needed for this part at all).
- `recon_engine.py` builds the comparison as plain SQL and runs it via
  the **Statement Execution API** against the SQL Warehouse you point
  it at:
  - `full_row` mode: `SELECT * FROM source EXCEPT SELECT * FROM target`
  - `key` mode: `SELECT s.* FROM source s WHERE NOT EXISTS (SELECT 1 FROM target t WHERE ...)`
- `main.py` is the job entry point: parses parameters (including
  `warehouse_id`), validates both tables exist, runs the
  reconciliation, prints a JSON result, and exits non-zero on FAIL.
- The Databricks Job itself runs on **serverless job compute** (see
  the `environments` block in `resources/recon_job.yml`) - there's no
  cluster to provision, size, or manage. The job task just makes API
  calls; the SQL Warehouse does the actual query execution.

## Why no Spark / job cluster?

The comparison is expressible entirely as SQL, so there's nothing a
Spark DataFrame gives you here that a warehouse query doesn't. The
trade-off:

- **Faster, cheaper**: a serverless SQL Warehouse starts in seconds
  and auto-suspends when idle; a job cluster takes a minute-plus to
  provision and bills for the whole lifetime.
- **Simpler dependency footprint**: no `pyspark` dependency, tests run
  against a mocked API response instead of a local Spark session.
- **Trade-off**: if you outgrow plain SQL (custom Python-side
  validation rules, non-SQL-expressible logic), you'd need to
  reintroduce a Spark path for that specific case. Not needed today.

## Two ways to run this

**While developing/debugging:** open `notebooks/interactive_test.py`
in the Databricks workspace, attach it to any small cluster (it's
only making API calls, not doing Spark work), fill in the widgets
including `warehouse_id`, run the cells. This exercises the exact
same `recon_engine.reconcile()` function production uses.

**In production:** GitLab CI deploys this as a Databricks Job (via
`databricks bundle deploy`) and triggers it (`databricks bundle run`)
with parameters. GitLab never runs the comparison itself - it tells
Databricks to run the job, which calls the SQL Warehouse, and waits
for the result.

## Placeholders to fill in once confirmed

Two things you flagged as still-changing are declared as **bundle
variables** in `databricks.yml` — a single place to update rather than
scattered across files:

```yaml
variables:
  workspace_host:
    default: "https://<qbq-zns-prf-test-a1>.azuredatabricks.net"  # update with real host
  warehouse_name:
    default: "npd-prf-test-sqlw-a1"  # update if the warehouse is renamed
```

The warehouse is referenced **by name**, not ID — `resolve_warehouse_id()`
in `catalog_utils.py` looks it up via the SDK at runtime, so there's no
separate ID to keep in sync if the warehouse is ever recreated. If you
later do want to pin an exact ID (skips the lookup call), pass
`warehouse_id` instead — it takes priority over `warehouse_name` when
both are set, everywhere in this repo (job parameters, notebook widget,
`main.py` args).

Catalog, schema, and table (source and target, all six) are **not**
declared here — per the original design, those are supplied per-run:
as job parameters when triggered from GitLab, or as notebook widgets
when testing interactively. Nothing to hardcode for those.

## One-time setup

1. **Create a Databricks service principal** (account console), grant
   it `USE CATALOG` / `USE SCHEMA` / `SELECT` on whatever catalogs
   this will reconcile, and `CAN_USE` on the SQL Warehouse. Generate
   an OAuth secret for it.
2. **In GitLab**, go to Settings > CI/CD > Variables and add, masked +
   protected:
   - `DATABRICKS_HOST`
   - `DATABRICKS_CLIENT_ID`
   - `DATABRICKS_CLIENT_SECRET`
3. **Update the variables block in `databricks.yml`** (see above) once
   the real workspace host is confirmed, and `<your-service-principal-application-id>`
   under the `prod` target's `run_as`.
4. **Install the Databricks CLI locally** if you want to test bundle
   commands before pushing:
   ```
   curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sh
   databricks bundle validate --target dev
   databricks bundle deploy --target dev
   ```

## Running a reconciliation from GitLab

Go to CI/CD > Pipelines > Run pipeline, and add these as pipeline
variables for that run:

| Variable | Example |
|---|---|
| `WAREHOUSE_NAME` | `npd-prf-test-sqlw-a1` |
| `WAREHOUSE_ID` | *(leave blank — resolved from the name above)* |
| `SOURCE_CATALOG` | `legacy_catalog` |
| `SOURCE_SCHEMA` | `sales` |
| `SOURCE_TABLE` | `orders` |
| `TARGET_CATALOG` | `uc_catalog` |
| `TARGET_SCHEMA` | `sales` |
| `TARGET_TABLE` | `orders` |
| `COMPARE_MODE` | `full_row` or `key` |
| `KEY_COLUMNS` | `order_id` (only needed if COMPARE_MODE=key) |

The pipeline runs unit tests, deploys the bundle, then triggers the
job with those parameters. Pipeline goes green on PASS, red on FAIL.

## Unit tests (no Databricks connection needed)

```
pip install -e ".[dev]"
pytest tests/ -v
```

These mock the Statement Execution API response, so they run in
seconds with no workspace, no credentials, no network, and no
`pyspark` dependency at all.

## Choosing full_row vs key compare_mode

- `full_row` (default): every column must match exactly. Use when
  source and target are meant to be identical (e.g. straight copy or
  migration).
- `key`: only a business key must be present in both. Use when the
  target legitimately has extra/derived columns, or you only care
  that no source records were dropped.

## Safety behaviors worth knowing about

- **Duplicate rows are not silently ignored.** `full_row` mode uses
  `EXCEPT ALL`, not plain `EXCEPT` — plain `EXCEPT` is `EXCEPT DISTINCT`
  under the hood and would report a false PASS if a source row is
  duplicated but the target only has one copy.
- **Row samples are opt-in.** On FAIL, only the *count* of mismatched
  rows is logged by default — not the row values — since the tables
  being reconciled may hold sensitive data that shouldn't land in job
  run logs. Pass `include_row_samples=true` (job parameter / notebook
  widget / `--include_row_samples true`) to see actual mismatched rows,
  a deliberate choice you make per run rather than a default.
- **Schema drift fails fast, before any comparison runs.** `full_row`
  mode checks that source and target have the exact same set of
  columns (via `information_schema.columns`) and selects both sides by
  an identical, explicit column list — not `SELECT *` — because
  `EXCEPT`/`EXCEPT ALL` compare column-by-*position*, so two tables
  with the same columns in a different physical order would otherwise
  compare the wrong values against each other without warning. `key`
  mode checks the given key column(s) actually exist on both sides. A
  mismatch raises `SchemaMismatchError` and the job exits with code 3,
  distinct from a normal FAIL (exit 1), so you can tell "shapes don't
  match" apart from "data doesn't match" in job logs/alerts.

## Repo layout

```
databricks.yml              Asset Bundle config (targets, workspace, wheel build)
resources/recon_job.yml     Job definition: parameters, serverless environment, tasks
src/recon_framework/        The actual package
  catalog_utils.py          Auth + catalog/schema/table discovery (Unity Catalog metadata)
  recon_engine.py           Comparison logic, run as SQL on a Warehouse via Statement Execution API
  main.py                   Job entry point, arg parsing, exit codes
pyproject.toml               Packaging + console-script entry points
notebooks/interactive_test.py   Manual testing notebook (widgets, no CI)
tests/test_recon_engine.py   Local pytest suite (mocked API, no real warehouse needed)
config/recon_targets.yml    Optional: batch of table pairs (not wired in yet)
.gitlab-ci.yml               test -> deploy -> run pipeline
```

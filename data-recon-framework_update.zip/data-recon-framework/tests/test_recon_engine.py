"""
Unit tests for the SQL-Warehouse-based comparison engine. No live
Databricks connection needed - the Statement Execution API is mocked,
so these run anywhere in seconds.
"""

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
from databricks.sdk.service.sql import StatementState

from recon_framework.catalog_utils import resolve_warehouse_id
from recon_framework.recon_engine import SchemaMismatchError, reconcile


def _fake_resp(rows: list[list]):
    """Build a minimal object matching the shape of what
    w.statement_execution.execute_statement() returns."""
    return SimpleNamespace(
        statement_id="fake-statement-id",
        status=SimpleNamespace(state=StatementState.SUCCEEDED, error=None),
        result=SimpleNamespace(data_array=rows),
    )


def _cols_resp(names: list[str]):
    return _fake_resp([[n] for n in names])


def test_full_row_pass_when_no_missing_rows():
    w = MagicMock()
    # Call order: source cols, target cols, COUNT(missing),
    # source COUNT(*), target COUNT(*)
    w.statement_execution.execute_statement.side_effect = [
        _cols_resp(["id", "val"]),
        _cols_resp(["id", "val"]),
        _fake_resp([[0]]),
        _fake_resp([[100]]),
        _fake_resp([[100]]),
    ]

    result = reconcile(w, "wh123", "src.sch.tbl", "tgt.sch.tbl", compare_mode="full_row")

    assert result.status == "PASS"
    assert result.missing_in_target == 0
    assert result.source_row_count == 100
    assert result.target_row_count == 100


def test_full_row_fail_when_rows_missing_but_samples_not_fetched_by_default():
    w = MagicMock()
    # No sample-rows call expected since include_row_samples defaults to False:
    # cols, cols, COUNT(missing), source COUNT(*), target COUNT(*)
    w.statement_execution.execute_statement.side_effect = [
        _cols_resp(["id", "val"]),
        _cols_resp(["id", "val"]),
        _fake_resp([[2]]),
        _fake_resp([[100]]),
        _fake_resp([[98]]),
    ]

    result = reconcile(w, "wh123", "src.sch.tbl", "tgt.sch.tbl", compare_mode="full_row")

    assert result.status == "FAIL"
    assert result.missing_in_target == 2
    assert w.statement_execution.execute_statement.call_count == 5  # no extra sample call


def test_full_row_fetches_samples_when_explicitly_requested():
    w = MagicMock()
    w.statement_execution.execute_statement.side_effect = [
        _cols_resp(["id", "val"]),
        _cols_resp(["id", "val"]),
        _fake_resp([[2]]),
        _fake_resp([[1, "a"], [2, "b"]]),  # sample rows
        _fake_resp([[100]]),
        _fake_resp([[98]]),
    ]

    result = reconcile(
        w, "wh123", "src.sch.tbl", "tgt.sch.tbl",
        compare_mode="full_row", include_row_samples=True,
    )

    assert result.status == "FAIL"
    assert w.statement_execution.execute_statement.call_count == 6


def test_full_row_raises_on_column_mismatch_without_running_comparison():
    w = MagicMock()
    w.statement_execution.execute_statement.side_effect = [
        _cols_resp(["id", "val", "region"]),
        _cols_resp(["id", "val"]),
    ]

    with pytest.raises(SchemaMismatchError, match="region"):
        reconcile(w, "wh123", "src.sch.tbl", "tgt.sch.tbl", compare_mode="full_row")

    # Only the two column-lookup calls should have happened - no
    # comparison query run against mismatched schemas.
    assert w.statement_execution.execute_statement.call_count == 2


def test_key_mode_pass_when_all_keys_present():
    w = MagicMock()
    # Call order: source cols (key check), target cols (key check),
    # COUNT(missing), source COUNT(*), target COUNT(*)
    w.statement_execution.execute_statement.side_effect = [
        _cols_resp(["id", "val"]),
        _cols_resp(["id", "val", "extra_col"]),
        _fake_resp([[0]]),
        _fake_resp([[50]]),
        _fake_resp([[50]]),
    ]

    result = reconcile(
        w, "wh123", "src.sch.tbl", "tgt.sch.tbl",
        compare_mode="key", key_columns=["id"],
    )

    assert result.status == "PASS"


def test_key_mode_requires_key_columns():
    w = MagicMock()
    with pytest.raises(ValueError):
        reconcile(w, "wh123", "src.sch.tbl", "tgt.sch.tbl", compare_mode="key", key_columns=None)


def test_key_mode_raises_when_key_column_missing():
    w = MagicMock()
    w.statement_execution.execute_statement.side_effect = [
        _cols_resp(["id", "val"]),
        _cols_resp(["val"]),  # target is missing "id"
    ]

    with pytest.raises(SchemaMismatchError, match="Missing from target"):
        reconcile(w, "wh123", "src.sch.tbl", "tgt.sch.tbl", compare_mode="key", key_columns=["id"])


def test_resolve_warehouse_id_finds_matching_name():
    w = MagicMock()
    w.warehouses.list.return_value = [
        SimpleNamespace(name="npd-prf-test-sqlw-a1", id="wh-abc123"),
        SimpleNamespace(name="some-other-warehouse", id="wh-xyz789"),
    ]

    warehouse_id = resolve_warehouse_id("npd-prf-test-sqlw-a1", w)

    assert warehouse_id == "wh-abc123"


def test_resolve_warehouse_id_raises_when_not_found():
    w = MagicMock()
    w.warehouses.list.return_value = [
        SimpleNamespace(name="some-other-warehouse", id="wh-xyz789"),
    ]

    with pytest.raises(ValueError):
        resolve_warehouse_id("does-not-exist", w)

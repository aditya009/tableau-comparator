# Databricks notebook source
# MAGIC %md
# MAGIC # Interactive reconciliation test
# MAGIC Run this attached to any cluster (a small one is fine - it's just
# MAGIC calling APIs, no Spark work happens locally). The actual
# MAGIC comparison query executes on the SQL Warehouse you specify below,
# MAGIC which is exactly the same code path production uses - so a pass
# MAGIC here means the GitLab-triggered run will behave the same way.

# COMMAND ----------

# MAGIC %pip install -e /Workspace/Repos/<you>/data-recon-framework
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

from recon_framework.catalog_utils import get_client, list_catalogs

w = get_client()
print(list_catalogs(w))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Widgets so you can change tables/warehouse without editing code

# COMMAND ----------

dbutils.widgets.text("warehouse_name", "npd-prf-test-sqlw-a1")
dbutils.widgets.text("warehouse_id", "")  # leave blank to resolve from the name above
dbutils.widgets.text("source_catalog", "")
dbutils.widgets.text("source_schema", "")
dbutils.widgets.text("source_table", "")
dbutils.widgets.text("target_catalog", "")
dbutils.widgets.text("target_schema", "")
dbutils.widgets.text("target_table", "")
dbutils.widgets.dropdown("compare_mode", "full_row", ["full_row", "key"])
dbutils.widgets.text("key_columns", "")
dbutils.widgets.dropdown("include_row_samples", "false", ["false", "true"])

# COMMAND ----------

from recon_framework.catalog_utils import resolve_warehouse_id
from recon_framework.recon_engine import reconcile

source_fqn = f"{dbutils.widgets.get('source_catalog')}.{dbutils.widgets.get('source_schema')}.{dbutils.widgets.get('source_table')}"
target_fqn = f"{dbutils.widgets.get('target_catalog')}.{dbutils.widgets.get('target_schema')}.{dbutils.widgets.get('target_table')}"
key_cols_raw = dbutils.widgets.get("key_columns")
key_columns = [c.strip() for c in key_cols_raw.split(",") if c.strip()] or None

warehouse_id = dbutils.widgets.get("warehouse_id") or resolve_warehouse_id(
    dbutils.widgets.get("warehouse_name"), w
)

result = reconcile(
    w=w,
    warehouse_id=warehouse_id,
    source_fqn=source_fqn,
    target_fqn=target_fqn,
    compare_mode=dbutils.widgets.get("compare_mode"),
    key_columns=key_columns,
    include_row_samples=dbutils.widgets.get("include_row_samples") == "true",
)

print(result.as_dict())
